"""Faux module ``streamlit`` pour exécuter ``app.main()`` dans les tests sans installer Streamlit.

Il ne remplace pas un test réel de l'interface (voir README) : il attrape les erreurs de nom,
d'import, de signature et de logique d'affichage sur le chemin « sans secrets » et « avec index ».
"""

from __future__ import annotations

import sys
import types
from contextlib import contextmanager
from typing import Any


class _Null:
    """Objet inerte : appelable, utilisable avec ``with``, itérable (vide)."""

    def __call__(self, *args: Any, **kwargs: Any) -> "_Null":
        return self

    def __getattr__(self, name: str) -> "_Null":
        return self

    def __enter__(self) -> "_Null":
        return self

    def __exit__(self, *exc: Any) -> bool:
        return False

    def __iter__(self):
        return iter(())

    def __bool__(self) -> bool:
        return False


class _NoSecrets:
    def __iter__(self):
        raise FileNotFoundError("No secrets found")

    def __getitem__(self, key: str):
        raise FileNotFoundError("No secrets found")


class _Cacheable:
    def __init__(self, fn):
        self.fn = fn
        self.__name__ = getattr(fn, "__name__", "cached")

    def __call__(self, *args: Any, **kwargs: Any):
        return self.fn(*args, **kwargs)

    def clear(self) -> None:
        pass


def _cache_decorator(*args: Any, **kwargs: Any):
    if args and callable(args[0]) and not kwargs:
        return _Cacheable(args[0])
    return lambda fn: _Cacheable(fn)


class StreamlitStub(types.ModuleType):
    def __init__(self, secrets: dict[str, Any] | None = None, inputs: dict[str, Any] | None = None) -> None:
        super().__init__("streamlit")
        self.messages: list[tuple[str, str]] = []
        self.session_state: dict[str, Any] = {}
        self.secrets: Any = secrets if secrets is not None else _NoSecrets()
        self._inputs = inputs or {}
        self.cache_resource = _cache_decorator
        self.cache_data = _cache_decorator
        self.sidebar = _Box(self)
        self.downloads: list[Any] = []

    def __getattr__(self, name: str) -> Any:  # widgets sans effet testable (divider, image, ...)
        return _Null()

    def _log(self, kind: str, text: Any) -> None:
        self.messages.append((kind, str(text)))

    # --- sorties texte
    def title(self, text, *a, **k): self._log("title", text)
    def header(self, text, *a, **k): self._log("header", text)
    def subheader(self, text, *a, **k): self._log("subheader", text)
    def caption(self, text, *a, **k): self._log("caption", text)
    def write(self, *args, **k): self._log("write", " ".join(map(str, args)))
    def markdown(self, text, *a, **k): self._log("markdown", text)
    def info(self, text, *a, **k): self._log("info", text)
    def warning(self, text, *a, **k): self._log("warning", text)
    def error(self, text, *a, **k): self._log("error", text)
    def success(self, text, *a, **k): self._log("success", text)
    def table(self, *a, **k): self._log("table", a)
    def dataframe(self, *a, **k): self._log("dataframe", a)
    def metric(self, *a, **k): self._log("metric", a)

    # --- entrées
    def text_input(self, label, value="", **k): return self._inputs.get(k.get("key", label), value)
    def text_area(self, label, value="", **k): return self._inputs.get(k.get("key", label), value)
    def number_input(self, label, *a, value=0.0, **k): return value
    def slider(self, label, *a, **k):
        if "value" in k:
            return k["value"]
        return a[2] if len(a) >= 3 else (a[0] if a else 0)
    def multiselect(self, label, options=(), default=None, **k): return list(default or [])
    def checkbox(self, label, value=False, **k): return self._inputs.get(label, value)
    def radio(self, label, options, **k): return options[0]
    def button(self, label, **k): return self._inputs.get(k.get("key") or label, False)
    def file_uploader(self, *a, **k): return None
    def download_button(self, *a, **k): self.downloads.append((a, k)); return False
    def link_button(self, *a, **k): return None

    # --- structure
    def columns(self, spec, **k):
        count = spec if isinstance(spec, int) else len(spec)
        return [_Null() for _ in range(count)]
    def tabs(self, labels): return [_Null() for _ in labels]
    def container(self, *a, **k): return _Box(self)
    def expander(self, *a, **k): return _Null()
    def progress(self, *a, **k): return _Null()
    def set_page_config(self, *a, **k): return None
    def rerun(self): raise RuntimeError("rerun")


class _Box(_Null):
    """Conteneur / barre latérale : les appels sont journalisés comme ceux du module racine."""

    def __init__(self, root: StreamlitStub) -> None:
        self._root = root

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._root, name, None)
        return attr if callable(attr) else _Null()

    def __enter__(self) -> "_Box":
        return self


_Sidebar = _Box


@contextmanager
def installed(stub: StreamlitStub):
    """Installe le faux module, recharge ``app`` et le retire ensuite."""
    previous = sys.modules.get("streamlit")
    sys.modules["streamlit"] = stub
    sys.modules.pop("app", None)
    try:
        yield
    finally:
        sys.modules.pop("app", None)
        if previous is None:
            sys.modules.pop("streamlit", None)
        else:
            sys.modules["streamlit"] = previous
