"""Génère de vrais PDF (texte extractible + poids incompressible optionnel) sans dépendance externe."""

from __future__ import annotations

import os
from pathlib import Path


def _escape(text: str) -> bytes:
    data = text.encode("cp1252", errors="replace")
    return data.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


def build_pdf(pages: list[str], filler_bytes_per_page: int = 0) -> bytes:
    """``pages`` : texte de chaque page (lignes séparées par ``\\n``).

    ``filler_bytes_per_page`` ajoute une image de bruit aléatoire (incompressible) pour fabriquer
    des PDF lourds réalistes.
    """
    objects: list[bytes] = []

    def add(body: bytes) -> int:
        objects.append(body)
        return len(objects)

    catalog_id = add(b"")  # remplacé plus bas
    pages_id = add(b"")
    font_id = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    page_ids: list[int] = []
    for text in pages:
        ops = [b"BT /F1 11 Tf 14 TL 40 780 Td"]
        for line in text.split("\n"):
            ops.append(b"(" + _escape(line) + b") Tj T*")
        ops.append(b"ET")
        resources = f"/Font << /F1 {font_id} 0 R >>"
        if filler_bytes_per_page:
            side = int(filler_bytes_per_page**0.5) or 1
            noise = os.urandom(side * side)
            image_id = add(
                f"<< /Type /XObject /Subtype /Image /Width {side} /Height {side} /ColorSpace /DeviceGray "
                f"/BitsPerComponent 8 /Length {len(noise)} >>\nstream\n".encode() + noise + b"\nendstream"
            )
            resources += f" /XObject << /Im1 {image_id} 0 R >>"
            ops.append(b"q 8 0 0 8 40 40 cm /Im1 Do Q")
        stream = b"\n".join(ops)
        content_id = add(f"<< /Length {len(stream)} >>\nstream\n".encode() + stream + b"\nendstream")
        page_ids.append(
            add(
                f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 595 842] "
                f"/Resources << {resources} >> /Contents {content_id} 0 R >>".encode()
            )
        )
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[catalog_id - 1] = f"<< /Type /Catalog /Pages {pages_id} 0 R >>".encode()
    objects[pages_id - 1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode()

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets: list[int] = []
    for number, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{number} 0 obj\n".encode() + body + b"\nendobj\n"
    xref_at = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    for offset in offsets:
        out += f"{offset:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_id} 0 R >>\nstartxref\n{xref_at}\n%%EOF\n".encode()
    return bytes(out)


def write_pdf(path: Path, pages: list[str], filler_bytes_per_page: int = 0) -> Path:
    path.write_bytes(build_pdf(pages, filler_bytes_per_page))
    return path
