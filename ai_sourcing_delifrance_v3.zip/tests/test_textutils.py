import unittest

from sourcing.textutils import (
    build_query_plan, extract_packaging, extract_references, extract_weights, normalize, strip_weights,
    weight_proximity,
)


class WeightTests(unittest.TestCase):
    def test_variants_of_40_grams(self):
        for text in ("Mini danish 40 g", "mini danish 40g", "40 gr", "0,04 kg", "40 grammes"):
            self.assertEqual(extract_weights(text), [40.0], text)

    def test_kilograms_and_multipacks(self):
        self.assertEqual(extract_weights("sachet 1,2 kg"), [1200.0])
        self.assertEqual(extract_weights("6 x 1 kg"), [1000.0])
        self.assertEqual(extract_weights("2x500g"), [500.0])

    def test_range_gives_both_ends(self):
        self.assertEqual(extract_weights("35-45 g"), [35.0, 45.0])

    def test_nutrition_values_are_not_weights(self):
        table = "Valeurs nutritionnelles pour 100 g\nLipides 12 g\ndont saturés 5,1 g\nSel 1,1 g\nProtéines 7 g"
        self.assertEqual(extract_weights(table), [])

    def test_words_starting_with_g_are_not_weights(self):
        self.assertEqual(extract_weights("40 gluten 12 grandes"), [])

    def test_strip_weights_keeps_product_name(self):
        self.assertEqual(normalize(strip_weights("Mini Danish 40 g")), "mini danish")

    def test_proximity(self):
        self.assertEqual(weight_proximity(40, [40.5], 0.15), 1.0)
        self.assertGreater(weight_proximity(40, [38], 0.15), 0.0)
        self.assertLess(weight_proximity(40, [38], 0.15), 1.0)
        self.assertEqual(weight_proximity(40, [85], 0.15), 0.0)
        self.assertEqual(weight_proximity(40, [], 0.15), 0.0)


class ReferenceAndPackagingTests(unittest.TestCase):
    def test_labeled_ean_and_line_start_codes(self):
        text = "Réf. 41234 Croissant\n3250540123456\n123456 Mini danish pomme"
        refs = extract_references(text)
        self.assertIn("41234", refs)
        self.assertIn("3250540123456", refs)
        self.assertIn("123456", refs)

    def test_certifications_are_not_references(self):
        self.assertEqual(extract_references("Certifié ISO22000 et IFS6"), [])

    def test_packaging(self):
        self.assertIn("carton de 120", extract_packaging("Mini danish 40 g - carton de 120"))
        self.assertIn("24 pièces", extract_packaging("boîte de 24 pièces"))


class QueryPlanTests(unittest.TestCase):
    def test_mini_danish_40g(self):
        plan = build_query_plan("Mini Danish 40 g")
        self.assertEqual(plan.weight_g, 40.0)
        self.assertEqual(plan.tokens, ("mini", "danish"))
        self.assertEqual([f.key for f in plan.families], ["danish"])
        self.assertIn("mini", plan.modifiers)
        self.assertIn("viennoiserie", plan.categories)
        self.assertIn("pate danoise", plan.synonyms)

    def test_french_and_english_synonyms_share_a_family(self):
        self.assertEqual([f.key for f in build_query_plan("pâte danoise").families], ["danish"])
        self.assertEqual([f.key for f in build_query_plan("danish pastry").families], ["danish"])

    def test_empty_query(self):
        self.assertTrue(build_query_plan("   ").is_empty)

    def test_reference_query(self):
        plan = build_query_plan("UB-5521")
        self.assertEqual(plan.references, ("UB5521",))


if __name__ == "__main__":
    unittest.main()
