"""Doubles de test : réponses HTTP, sessions et recherche Tavily simulées."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import requests


class FakeResponse:
    def __init__(self, status: int = 200, json_data: Any = None, content: bytes = b"", headers: dict | None = None):
        self.status_code = status
        self._json = json_data
        self.content = content
        self.headers = headers or {}
        self.closed = False

    def json(self) -> Any:
        if self._json is None:
            raise ValueError("no json")
        return self._json

    def iter_content(self, chunk_size: int = 8192):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i : i + chunk_size]

    def close(self) -> None:
        self.closed = True


class FakeSession:
    """Rejoue des réponses dans l'ordre ; une exception dans la liste est levée."""

    def __init__(self, responses: list[Any] | Callable[[str, str, dict], Any]):
        self._responses = responses
        self.calls: list[tuple[str, str, dict]] = []

    def request(self, method: str, url: str, **kwargs: Any) -> Any:
        self.calls.append((method, url, kwargs))
        if callable(self._responses):
            item = self._responses(method, url, kwargs)
        else:
            item = self._responses.pop(0) if len(self._responses) > 1 else self._responses[0]
        if isinstance(item, Exception):
            raise item
        return item


def no_sleep(_: float) -> None:
    return None


@dataclass(frozen=True)
class FakeRemote:
    public_id: str
    version: str = "1"
    bytes: int = 1000
    etag: str = "e1"
    resource_type: str = "raw"
    secure_url: str = "https://res.cloudinary.com/demo/raw/upload/v1/x.pdf"

    @property
    def fingerprint(self) -> str:
        return f"{self.resource_type}|{self.public_id}|{self.version}|{self.bytes}|{self.etag}"


@dataclass
class FakeSearcher:
    """Tavily simulé : ``discovery`` pour les requêtes libres, ``by_domain`` pour include_domains."""

    discovery: list[dict[str, Any]] = field(default_factory=list)
    by_domain: dict[str, list[dict[str, Any]]] = field(default_factory=dict)
    error: Exception | None = None
    calls: list[tuple[str, list[str] | None]] = field(default_factory=list)

    def search(self, query: str, *, include_domains=None, exclude_domains=None, max_results: int = 8):
        self.calls.append((query, include_domains))
        if self.error:
            raise self.error
        if include_domains:
            return list(self.by_domain.get(include_domains[0], []))
        return list(self.discovery)


def result(url: str, title: str = "", content: str = "", score: float = 0.5) -> dict[str, Any]:
    return {"url": url, "title": title, "content": content, "score": score}
