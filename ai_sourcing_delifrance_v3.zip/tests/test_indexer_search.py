import tempfile
import unittest
from pathlib import Path

from sourcing.catalog_names import parse_catalog_name
from sourcing.errors import NetworkError
from sourcing.indexer import plan_sync, sync_index
from sourcing.internal_search import ScoringConfig, SearchFilters, search_internal
from sourcing.store import IndexStore
from tests.fakes import FakeRemote
from tests.pdf_factory import write_pdf

CATALOGS = {
    "ai-sourcing/catalogues/Bridor_Viennoiserie_part_01_pages_1-2.pdf": [
        "SOMMAIRE\nViennoiserie\nTable des matières",
        "MINI DANISH POMME\nRéf. 41234\nMini danish aux pommes 40 g\nCarton de 120 pièces\n\n"
        "CROISSANT BEURRE\nRéf. 41300\nCroissant pur beurre 60 g carton de 90",
    ],
    "ai-sourcing/catalogues/Bridor_Viennoiserie_part_02_pages_3-4.pdf": [
        "MINI DANISH FRAMBOISE\nRéf. 41235\nMini danish framboise 85 g\nCarton de 60 pièces",
        "Valeurs nutritionnelles pour 100 g\nLipides 12 g\nSel 1,1 g",
    ],
    "ai-sourcing/catalogues/Unibake_Danish_Pastry_2025.pdf": [
        "DANISH PASTRY CUSTARD\nCode: UB-5521\nDanish pastry custard 40g box of 120 pcs",
        "PAIN BURGER\nRéf. 9988\nPain burger 80 g carton de 48",
    ],
}


class FakeClient:
    def __init__(self, docs=None, fail=()):
        self.docs, self.fail, self.downloads = docs or CATALOGS, set(fail), []

    def download_to_file(self, remote, dest):
        self.downloads.append(remote.public_id)
        if remote.public_id in self.fail:
            raise NetworkError("Cloudinary : échec simulé")
        content = self.docs[remote.public_id]
        if isinstance(content, bytes):
            Path(dest).write_bytes(content)
        else:
            write_pdf(Path(dest), content)
        return 1


class IndexTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.store = IndexStore(self.tmp / "index.sqlite")
        self.remotes = [FakeRemote(pid) for pid in CATALOGS]

    def tearDown(self):
        self._tmp.cleanup()


class IncrementalIndexTests(IndexTestCase):
    def test_second_sync_downloads_nothing(self):
        client = FakeClient()
        first = sync_index(self.store, client, self.remotes)
        self.assertEqual(first.indexed, 3)
        self.assertEqual(len(client.downloads), 3)
        again = sync_index(self.store, client, self.remotes)
        self.assertEqual((again.indexed, again.unchanged), (0, 3))
        self.assertEqual(len(client.downloads), 3)

    def test_changed_fingerprint_reindexes_only_that_file(self):
        client = FakeClient()
        sync_index(self.store, client, self.remotes)
        changed = [FakeRemote(r.public_id, version="2") if "Unibake" in r.public_id else r for r in self.remotes]
        plan = plan_sync(self.store, changed)
        self.assertEqual([r.public_id for r in plan.to_index], ["ai-sourcing/catalogues/Unibake_Danish_Pastry_2025.pdf"])

    def test_removed_remote_is_removed_from_index(self):
        sync_index(self.store, FakeClient(), self.remotes)
        report = sync_index(self.store, FakeClient(), self.remotes[:2])
        self.assertEqual(report.removed, 1)
        self.assertEqual(self.store.stats().files, 2)

    def test_index_version_changes_so_caches_invalidate(self):
        before = self.store.version()
        sync_index(self.store, FakeClient(), self.remotes[:1])
        self.assertGreater(self.store.version(), before)

    def test_one_failing_pdf_does_not_stop_the_others_and_is_retried(self):
        bad = self.remotes[1].public_id
        client = FakeClient(fail={bad})
        report = sync_index(self.store, client, self.remotes)
        self.assertEqual(report.indexed, 2)
        self.assertEqual(len(report.errors), 1)
        self.assertEqual(self.store.stats().errors, 1)
        retry = sync_index(self.store, FakeClient(), self.remotes)  # le réseau est revenu
        self.assertEqual(retry.indexed, 1)
        self.assertEqual(self.store.stats().errors, 0)

    def test_scanned_pdf_is_flagged_for_ocr_not_indexed_as_text(self):
        docs = {"scan.pdf": ["", "", ""]}
        report = sync_index(self.store, FakeClient(docs), [FakeRemote("scan.pdf")])
        self.assertEqual(report.needs_ocr, 1)
        files = self.store.list_files()
        self.assertEqual(files[0].status, "needs_ocr")
        self.assertIn("OCR", files[0].status_detail)

    def test_corrupt_pdf_is_recorded_as_error(self):
        report = sync_index(self.store, FakeClient({"bad.pdf": b"not a pdf at all" * 10}), [FakeRemote("bad.pdf")])
        self.assertEqual(len(report.errors), 1)
        self.assertEqual(self.store.stats().errors, 1)

    def test_work_directory_is_cleaned(self):
        work = self.tmp / "work"
        work.mkdir()
        sync_index(self.store, FakeClient(), self.remotes, work_dir=work)
        self.assertEqual(list(work.iterdir()), [])


class SearchTests(IndexTestCase):
    def setUp(self):
        super().setUp()
        sync_index(self.store, FakeClient(), self.remotes)

    def test_mini_danish_40g_ranks_the_right_product_first(self):
        hits = search_internal(self.store, "Mini Danish 40 g")
        self.assertEqual(hits[0].title, "MINI DANISH POMME")
        titles = [h.title for h in hits]
        self.assertNotIn("CROISSANT BEURRE", titles)
        self.assertNotIn("PAIN BURGER", titles)
        self.assertGreater(hits[0].score, hits[-1].score)

    def test_wrong_weight_is_penalised_and_explained(self):
        hits = {h.title: h for h in search_internal(self.store, "Mini Danish 40 g")}
        framboise = hits["MINI DANISH FRAMBOISE"]
        self.assertIn("grammage incompatible", framboise.penalties)
        self.assertGreater(hits["MINI DANISH POMME"].score, framboise.score)
        self.assertTrue(any("grammage" in n for n in framboise.notes))

    def test_original_page_numbers_are_rebuilt_from_parts(self):
        hits = {h.title: h for h in search_internal(self.store, "Mini Danish")}
        self.assertEqual(hits["MINI DANISH POMME"].page, 2)       # partie 1, page 2
        self.assertEqual(hits["MINI DANISH FRAMBOISE"].page, 3)   # partie 2 démarre p. 3
        self.assertIn("partie 2/2", hits["MINI DANISH FRAMBOISE"].page_label)

    def test_synonym_in_another_language_finds_the_family(self):
        titles = [h.title for h in search_internal(self.store, "pâte danoise 40 g")]
        self.assertIn("DANISH PASTRY CUSTARD", titles)

    def test_reference_search(self):
        hits = search_internal(self.store, "UB-5521")
        self.assertEqual(hits[0].title, "DANISH PASTRY CUSTARD")
        self.assertIn("référence", hits[0].components)

    def test_filters(self):
        only_bridor = search_internal(self.store, "Mini Danish", SearchFilters(suppliers=("BRIDOR",)))
        self.assertTrue(only_bridor and all(h.supplier == "BRIDOR" for h in only_bridor))
        heavy = search_internal(self.store, "Mini Danish", SearchFilters(min_weight_g=80, max_weight_g=90))
        self.assertEqual([h.title for h in heavy], ["MINI DANISH FRAMBOISE"])

    def test_fallback_without_fts_returns_same_top_result(self):
        fts = search_internal(self.store, "Mini Danish 40 g")[0].title
        like = search_internal(self.store, "Mini Danish 40 g", force_fallback=True)[0].title
        self.assertEqual(fts, like)

    def test_boilerplate_and_nutrition_are_not_returned_for_product_query(self):
        titles = [h.title for h in search_internal(self.store, "viennoiserie")]
        self.assertNotIn("Valeurs nutritionnelles pour 100 g", titles)

    def test_special_characters_do_not_break_fts(self):
        for query in ('mini "danish" OR (40', "danish*", "'; DROP TABLE passages;--", "***"):
            search_internal(self.store, query)  # ne doit pas lever
        self.assertGreater(self.store.stats().passages, 0)

    def test_empty_query_and_unknown_product(self):
        self.assertEqual(search_internal(self.store, ""), [])
        self.assertEqual(search_internal(self.store, "caviar beluga"), [])

    def test_score_is_points_with_explicit_maximum(self):
        hit = search_internal(self.store, "Mini Danish 40 g")[0]
        self.assertLessEqual(hit.score, hit.max_score)
        self.assertEqual(hit.max_score, sum([30, 25, 20, 15, 5]))
        self.assertIn("pts", hit.score_label)


class LegacyPartOffsetTests(IndexTestCase):
    def test_offsets_are_computed_from_previous_parts_when_name_has_no_start_page(self):
        docs = {"Cat part 1.pdf": ["PRODUIT A\nRéf. 11111 40 g", "x y z"], "Cat part 2.pdf": ["MINI DANISH LEGACY\nRéf. 22222 40 g"]}
        remotes = [FakeRemote(k) for k in docs]
        sync_index(self.store, FakeClient(docs), remotes)
        hit = search_internal(self.store, "mini danish legacy")[0]
        self.assertEqual(hit.page, 3)

    def test_unknown_offset_is_shown_honestly_when_a_previous_part_is_missing(self):
        docs = {"Cat part 2.pdf": ["MINI DANISH LEGACY\nRéf. 22222 40 g"]}
        sync_index(self.store, FakeClient(docs), [FakeRemote("Cat part 2.pdf")])
        hit = search_internal(self.store, "mini danish legacy")[0]
        self.assertIsNone(hit.page)
        self.assertIn("p. ?", hit.page_label)


if __name__ == "__main__":
    unittest.main()
