import hashlib
import tempfile
import unittest
from pathlib import Path

import requests

from cloudinary_pdf_tools import (
    API_BASE, CloudinaryAuthError, CloudinaryClient, CloudinaryConfig, CloudinaryConfigError, CloudinaryDeliveryError,
    RemotePdf, UploadJob, prepare_upload, run_upload, sign_params,
)
from sourcing.errors import NetworkError, QuotaError
from tests.fakes import FakeResponse, FakeSession, no_sleep
from tests.pdf_factory import write_pdf

SECRET = "SuperSecretValue987"
KEY = "123456789012345"
CONFIG = CloudinaryConfig(cloud_name="democloud", api_key=KEY, api_secret=SECRET)


def make_client(responses, **kwargs):
    session = FakeSession(responses)
    client = CloudinaryClient(CONFIG, session_factory=lambda: session, sleep=no_sleep, clock=lambda: 1700000000, **kwargs)
    return client, session


def remote(public_id="catalogues/Bridor/Cat__part01of02_p0001.pdf"):
    return RemotePdf(public_id, "1700000000", 1234, "etag1", "raw", "https://res.cloudinary.com/democloud/raw/upload/v1/x.pdf")


class ConfigTests(unittest.TestCase):
    def test_incomplete_config_is_explicit(self):
        with self.assertRaises(CloudinaryConfigError) as ctx:
            CloudinaryClient(CloudinaryConfig(cloud_name="x"))
        self.assertIn("CLOUDINARY_API_KEY", str(ctx.exception))

    def test_repr_never_shows_secrets(self):
        self.assertNotIn(SECRET, repr(CONFIG))
        self.assertNotIn(KEY, repr(CONFIG))
        self.assertNotIn(SECRET, CONFIG.cache_key())

    def test_from_cloudinary_url_and_nested_table(self):
        url = CloudinaryConfig.from_mapping({"CLOUDINARY_URL": f"cloudinary://{KEY}:{SECRET}@democloud"})
        self.assertEqual((url.cloud_name, url.api_key, url.api_secret), ("democloud", KEY, SECRET))
        nested = CloudinaryConfig.from_mapping({"cloudinary": {"cloud_name": "c", "api_key": "k", "api_secret": "s"}})
        self.assertTrue(nested.is_complete)

    def test_default_prefix_is_the_original_apps_folder_and_can_be_overridden(self):
        self.assertEqual(CloudinaryConfig.from_mapping({}).prefix, "ai-sourcing/catalogues")
        self.assertEqual(CloudinaryConfig.from_mapping({"CLOUDINARY_PREFIX": "/autre/dossier/"}).prefix, "autre/dossier")
        self.assertEqual(CloudinaryConfig.from_mapping({"CLOUDINARY_FOLDER": "ancien"}).prefix, "ancien")

    def test_example_values_are_treated_as_not_configured(self):
        cfg = CloudinaryConfig.from_mapping({"CLOUDINARY_CLOUD_NAME": "votre-cloud", "CLOUDINARY_API_KEY": "VOTRE_API_KEY",
                                             "CLOUDINARY_API_SECRET": "colle-ici"})
        self.assertFalse(cfg.is_complete)
        self.assertEqual(len(cfg.missing()), 3)

    def test_signature_matches_documented_algorithm(self):
        params = {"timestamp": 1315060510, "public_id": "sample_image", "eager": "w_400,h_300,c_pad|w_260,h_200,c_crop"}
        expected = hashlib.sha1(
            ("eager=w_400,h_300,c_pad|w_260,h_200,c_crop&public_id=sample_image&timestamp=1315060510" + "abcd").encode()
        ).hexdigest()
        self.assertEqual(sign_params(params, "abcd"), expected)
        self.assertEqual(len(sign_params(params, "abcd", "sha256")), 64)

    def test_signature_ignores_file_and_api_key(self):
        self.assertEqual(sign_params({"a": 1, "file": "x", "api_key": "k"}, "s"), sign_params({"a": 1}, "s"))


class ListTests(unittest.TestCase):
    def test_listing_uses_the_configured_prefix(self):
        client, session = make_client([FakeResponse(200, {"resources": []})])
        client.list_pdfs()
        self.assertEqual(session.calls[0][2]["params"]["prefix"], "ai-sourcing/catalogues")

    def test_pagination_and_pdf_filter(self):
        page1 = FakeResponse(200, {"resources": [
            {"public_id": "catalogues/A.pdf", "version": 1, "bytes": 10, "etag": "a", "secure_url": "u1"},
            {"public_id": "catalogues/readme.txt", "version": 1, "bytes": 1},
        ], "next_cursor": "CUR"})
        page2 = FakeResponse(200, {"resources": [{"public_id": "catalogues/B.PDF", "version": 2, "bytes": 20}]})
        client, session = make_client([page1, page2])
        found = client.list_pdfs()
        self.assertEqual([r.public_id for r in found], ["catalogues/A.pdf", "catalogues/B.PDF"])
        self.assertEqual(session.calls[1][2]["params"]["next_cursor"], "CUR")
        self.assertNotEqual(found[0].fingerprint, found[1].fingerprint)

    def test_invalid_credentials_message_is_actionable_and_secret_free(self):
        body = {"error": {"message": f"Invalid Signature {SECRET}"}}
        client, _ = make_client([FakeResponse(401, body)])
        with self.assertRaises(CloudinaryAuthError) as ctx:
            client.list_pdfs()
        message = str(ctx.exception)
        self.assertIn("CLOUDINARY_API_KEY", message)
        self.assertNotIn(SECRET, message)
        self.assertNotIn(KEY, message)

    def test_rate_limit(self):
        client, _ = make_client([FakeResponse(429, {})])
        with self.assertRaises(QuotaError):
            client.list_pdfs()


class RetryTests(unittest.TestCase):
    def test_temporary_server_errors_are_retried(self):
        ok = FakeResponse(200, {"resources": []})
        client, session = make_client([FakeResponse(503), FakeResponse(502), ok])
        self.assertEqual(client.list_pdfs(), [])
        self.assertEqual(len(session.calls), 3)

    def test_timeouts_end_with_a_clear_message_without_url_or_secret(self):
        client, session = make_client([requests.Timeout(f"read timeout url=https://x/?api_key={KEY}&signature={SECRET}")])
        with self.assertRaises(NetworkError) as ctx:
            client.list_pdfs()
        self.assertEqual(len(session.calls), 3)
        for forbidden in (SECRET, KEY, "https://"):
            self.assertNotIn(forbidden, str(ctx.exception))
        self.assertIn("délai dépassé", str(ctx.exception))

    def test_request_uses_timeout(self):
        client, session = make_client([FakeResponse(200, {"resources": []})])
        client.list_pdfs()
        self.assertIsNotNone(session.calls[0][2]["timeout"])


class DownloadTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dest = Path(self._tmp.name) / "x.pdf"

    def tearDown(self):
        self._tmp.cleanup()

    def test_public_delivery(self):
        client, session = make_client([FakeResponse(200, content=b"%PDF-1.4 data")])
        self.assertEqual(client.download_to_file(remote(), self.dest), 13)
        self.assertIn("res.cloudinary.com/democloud/raw/upload/v1700000000/catalogues/Bridor", session.calls[0][1])
        self.assertTrue(session.calls[0][2]["stream"])

    def test_401_on_delivery_falls_back_to_authenticated_download(self):
        client, session = make_client([FakeResponse(401, headers={"x-cld-error": "deny"}), FakeResponse(200, content=b"%PDF-ok")])
        client.download_to_file(remote(), self.dest)
        self.assertEqual(self.dest.read_bytes(), b"%PDF-ok")
        second = session.calls[1][1]
        self.assertTrue(second.startswith(f"{API_BASE}/democloud/raw/download?"))
        self.assertIn("signature=", second)
        self.assertNotIn(SECRET, second)  # le secret signe, il n'est jamais transmis

    def test_401_everywhere_explains_how_to_enable_pdf_delivery(self):
        client, _ = make_client([FakeResponse(401), FakeResponse(401)])
        with self.assertRaises(CloudinaryDeliveryError) as ctx:
            client.download_to_file(remote(), self.dest)
        message = str(ctx.exception)
        self.assertIn("PDF and ZIP files delivery", message)
        self.assertNotIn(SECRET, message)

    def test_empty_file_is_an_error(self):
        client, _ = make_client([FakeResponse(200, content=b"")])
        with self.assertRaises(Exception):
            client.download_to_file(remote(), self.dest)


class UploadTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_upload_is_signed_and_secret_is_not_sent(self):
        pdf = write_pdf(self.tmp / "a.pdf", ["page"])
        client, session = make_client([FakeResponse(200, {"public_id": "catalogues/a.pdf"})])
        client.upload_pdf(pdf, "catalogues/a.pdf")
        method, url, kwargs = session.calls[0]
        self.assertEqual((method, url), ("POST", f"{API_BASE}/democloud/raw/upload"))
        form = kwargs["data"]
        expected = sign_params({"public_id": "catalogues/a.pdf", "overwrite": True, "unique_filename": False,
                                "use_filename": False, "invalidate": True, "timestamp": 1700000000}, SECRET)
        self.assertEqual(form["signature"], expected)
        self.assertEqual(form["api_key"], KEY)
        self.assertNotIn(SECRET, str(form))

    def test_tags_are_signed_and_sent(self):
        pdf = write_pdf(self.tmp / "a.pdf", ["page"])
        client, session = make_client([FakeResponse(200, {"public_id": "a.pdf"})])
        client.upload_pdf(pdf, "a.pdf", tags=("ai-sourcing", "catalogue-fournisseur"))
        form = session.calls[0][2]["data"]
        self.assertEqual(form["tags"], "ai-sourcing,catalogue-fournisseur")
        expected = sign_params({"public_id": "a.pdf", "overwrite": True, "unique_filename": False, "use_filename": False,
                                "invalidate": True, "tags": "ai-sourcing,catalogue-fournisseur", "timestamp": 1700000000}, SECRET)
        self.assertEqual(form["signature"], expected)

    def test_too_large_file_message(self):
        pdf = write_pdf(self.tmp / "a.pdf", ["page"])
        client, _ = make_client([FakeResponse(400, {"error": {"message": "File size too large. Got 12000000"}})])
        with self.assertRaises(Exception) as ctx:
            client.upload_pdf(pdf, "a.pdf")
        self.assertIn("10 Mo", str(ctx.exception))

    def test_big_pdf_is_split_uploaded_in_parallel_and_resumed_after_a_failure(self):
        src = write_pdf(self.tmp / "gros.pdf", [f"Page {i}" for i in range(20)], filler_bytes_per_page=1_000_000)
        job = prepare_upload(src, self.tmp / "parts", stem="Gros", folder="catalogues/Test", max_bytes=4 * 1024 * 1024)
        self.assertGreater(len(job.parts), 2)
        failing = job.public_id(job.parts[1])
        state = {"fail_once": True, "uploaded": []}

        def handler(method, url, kwargs):
            if method == "GET":
                return FakeResponse(200, {"resources": [
                    {"public_id": pid, "version": 1, "bytes": size} for pid, size in state.get("remote", [])]})
            public_id = kwargs["data"]["public_id"]
            if public_id == failing and state["fail_once"]:
                return FakeResponse(400, {"error": {"message": "boom"}})
            state["uploaded"].append(public_id)
            return FakeResponse(200, {"public_id": public_id})

        client, _ = make_client(handler)
        run_upload(client, job, max_workers=3)
        self.assertEqual(len(job.failed), 1)
        self.assertFalse(job.complete)
        # reprise : seules les parties absentes sont renvoyées
        state["fail_once"] = False
        state["remote"] = [(job.public_id(p), p.size_bytes) for p in job.parts if job.public_id(p) != failing]
        state["uploaded"].clear()
        run_upload(client, job, max_workers=3)
        self.assertTrue(job.complete)
        self.assertEqual(state["uploaded"], [failing])


if __name__ == "__main__":
    unittest.main()
