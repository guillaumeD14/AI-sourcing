import unittest

from sourcing.blocks import build_blocks, looks_like_title
from sourcing.catalog_names import guess_supplier, parse_catalog_name, part_filename, safe_stem
from sourcing.suppliers import SupplierDirectory


class CatalogNameTests(unittest.TestCase):
    def test_original_app_convention_roundtrip(self):
        name = part_filename("Bridor_Catalogue_2025", 2, 46, 90)
        self.assertEqual(name, "Bridor_Catalogue_2025_part_02_pages_46-90.pdf")
        ref = parse_catalog_name(f"ai-sourcing/catalogues/viennoiseries/{name}")
        self.assertEqual((ref.part_index, ref.start_page, ref.end_page), (2, 46, 90))
        self.assertEqual(ref.page_offset, 45)
        self.assertEqual(ref.logical_name, "ai-sourcing/catalogues/viennoiseries/Bridor_Catalogue_2025")
        self.assertEqual(ref.supplier, "BRIDOR")

    def test_all_parts_share_the_same_logical_key(self):
        keys = {parse_catalog_name(f"x/Cat_part_0{i}_pages_{i * 10}-{i * 10 + 9}.pdf").logical_key for i in (1, 2, 3)}
        self.assertEqual(len(keys), 1)

    def test_legacy_part_names(self):
        ref = parse_catalog_name("Unibake Catalogue 2025 part 2.pdf")
        self.assertEqual((ref.part_index, ref.start_page), (2, None))
        self.assertIsNone(ref.page_offset)
        self.assertEqual(ref.supplier, "UNIBAKE")

    def test_plain_file_is_single_part_with_zero_offset(self):
        ref = parse_catalog_name("Bridor_Catalogue_2025.pdf")
        self.assertEqual((ref.part_index, ref.part_total, ref.page_offset), (1, 1, 0))

    def test_supplier_is_first_word_like_the_original_app(self):
        self.assertEqual(guess_supplier("KOHBERG_catalogue_2025"), "KOHBERG")
        self.assertEqual(guess_supplier("la-lorraine mini danish"), "LA")  # comportement d'origine, corrigé par la liste

    def test_official_name_from_supplier_list_when_unambiguous(self):
        directory = SupplierDirectory(["Kohberg Bakery Group A S", "Panificio Stefani Group Srl", "PANIFICIO CREMONA ITALIA", "LA LORRAINE NV"])
        self.assertEqual(guess_supplier("KOHBERG_catalogue_2025", directory), "Kohberg Bakery Group A S")
        self.assertEqual(guess_supplier("Panificio_Stefani_2025", directory), "Panificio Stefani Group Srl")
        self.assertEqual(guess_supplier("La_Lorraine_mini_danish", directory), "LA LORRAINE NV")
        self.assertEqual(guess_supplier("PANIFICIO_catalogue", directory), "PANIFICIO")  # ambigu : on n'invente pas
        ref = parse_catalog_name("ai-sourcing/catalogues/KOHBERG_catalogue_part_03_pages_91-135.pdf", directory)
        self.assertEqual(ref.supplier, "Kohberg Bakery Group A S")

    def test_safe_stem(self):
        self.assertEqual(safe_stem("Catalogue Été 2025 (v2).pdf"), "Catalogue_Été_2025_v2")


class BlockTests(unittest.TestCase):
    PAGE = (
        "CATALOGUE VIENNOISERIE 2025\n12\n\n"
        "MINI DANISH POMME\nRéf. 41234\nMini danish aux pommes 40 g\nCarton de 120 pièces\n"
        "MINI DANISH FRAMBOISE\nRéf. 41235\nMini danish framboise 40 g\nCarton de 120 pièces\n\n"
        "Valeurs nutritionnelles pour 100 g\nLipides 12 g\nwww.exemple.com\n"
    )

    def test_each_product_is_its_own_block_with_its_attributes(self):
        blocks = build_blocks(self.PAGE)
        products = [b for b in blocks if b.structured]
        self.assertEqual([b.title for b in products], ["MINI DANISH POMME", "MINI DANISH FRAMBOISE"])
        self.assertEqual(products[0].refs, ["41234"])
        self.assertEqual(products[1].refs, ["41235"])
        self.assertEqual(products[0].weights_g, [40.0])

    def test_noise_lines_are_dropped(self):
        text = " ".join(b.text for b in build_blocks(self.PAGE))
        self.assertNotIn("www.exemple.com", text)

    def test_one_line_per_product_tables(self):
        blocks = build_blocks("123456 Mini danish pomme 40 g carton de 120\n123457 Croissant beurre 60 g carton de 90\n")
        self.assertEqual(len(blocks), 2)
        self.assertTrue(all(b.structured for b in blocks))

    def test_duplicates_and_empty_pages(self):
        self.assertEqual(build_blocks(""), [])
        self.assertEqual(build_blocks("   \n \n"), [])
        repeated = build_blocks("MINI DANISH\nRéf. 41234 40 g\n\nMINI DANISH\nRéf. 41234 40 g\n")
        self.assertEqual(len(repeated), 1)

    def test_title_detection(self):
        self.assertTrue(looks_like_title("MINI DANISH POMME"))
        self.assertTrue(looks_like_title("Mini Danish Pomme"))
        self.assertFalse(looks_like_title("Cette phrase est une description longue et se termine par un point."))


if __name__ == "__main__":
    unittest.main()
