import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCANNED = {".py", ".md", ".toml", ".sh", ".ps1", ".csv", ".txt", ".json", ".cfg"}
FORBIDDEN = (
    (re.compile(r"tvly-[A-Za-z0-9]{12,}"), "clé Tavily"),
    (re.compile(r"cloudinary://\d{6,}:"), "URL Cloudinary avec identifiants"),
    (re.compile(r"(?i)api_secret\s*[:=]\s*[\"'](?!VOTRE_|xxx|\.\.\.|\*\*\*)[^\"']{6,}[\"']"), "secret Cloudinary en clair"),
)


def project_files():
    for path in ROOT.rglob("*"):
        parts = set(path.relative_to(ROOT).parts)
        if path.is_file() and path.suffix in SCANNED and not parts & {"tests", ".git", "__pycache__", "baseline_before_claude"}:
            yield path


class RepositoryHygieneTests(unittest.TestCase):
    def test_no_secret_in_project_files(self):
        for path in project_files():
            text = path.read_text(encoding="utf-8", errors="ignore")
            for pattern, label in FORBIDDEN:
                self.assertIsNone(pattern.search(text), f"{label} trouvé dans {path.relative_to(ROOT)}")

    def test_real_secrets_file_is_ignored_and_absent(self):
        self.assertFalse((ROOT / ".streamlit" / "secrets.toml").exists())
        gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")
        for needed in (".streamlit/secrets.toml", ".env", "*.sqlite"):
            self.assertIn(needed, gitignore)

    def test_example_secrets_only_contains_placeholders(self):
        example = (ROOT / "secrets.example.toml").read_text(encoding="utf-8")
        self.assertIn("CLOUDINARY_API_SECRET", example)
        self.assertIn("TAVILY_API_KEY", example)
        for line in example.splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                self.assertRegex(line.split("=", 1)[1].strip(), r'^"(VOTRE_[A-Z_]+|[a-z_/-]*)"$', line)

    def test_requirements_are_pinned_or_bounded(self):
        for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines():
            if line.strip() and not line.startswith("#"):
                self.assertRegex(line, r"(==|<)", f"dépendance non bornée : {line}")


if __name__ == "__main__":
    unittest.main()
