import unittest
from pathlib import Path

from sourcing.suppliers import SupplierDirectory, core_tokens

LIST_FILE = Path(__file__).resolve().parent.parent / "data" / "known_suppliers.txt"


class CoreNameTests(unittest.TestCase):
    def test_legal_forms_countries_and_codes_are_removed(self):
        cases = {
            "Lantmännen Unibake Germany GmbH & Co. KG": ("lantmannen", "unibake"),
            "Bakeline S,n,c,": ("bakeline",),
            "Frans Bagare 652-1009": ("frans", "bagare"),
            "VDM EUROPE IT Branch": ("vdm",),
            "MARGHERITA S.P.A. A SOCIO UNICO": ("margherita",),
            "ROMANS S.R.L.": ("romans",),
        }
        for raw, expected in cases.items():
            self.assertEqual(core_tokens(raw), expected, raw)


class ShippedListTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = SupplierDirectory.from_file(LIST_FILE)

    def test_list_is_loaded_completely(self):
        self.assertGreaterEqual(len(self.directory), 115)

    def test_known_companies_are_recognised_from_domain_or_title(self):
        known = [
            ("kohberg.com", ["Kohberg"], ""), ("europastry.com", ["Europastry"], ""),
            ("lantmannenunibake.com", ["Lantmännen Unibake"], ""), ("llbg.com", ["Llbg"], "La Lorraine Bakery Group"),
            ("pomone.fr", ["Pomone"], ""), ("dawnfoods.com", ["Dawn Foods"], ""),
            ("st-michel.com", ["St Michel Biscuits"], ""),
        ]
        for domain, names, text in known:
            self.assertIsNotNone(self.directory.match(names, domain, text), domain)

    def test_unknown_companies_and_generic_words_are_not_matched(self):
        unknown = [
            ("gourmandpastries.com", ["Gourmand Pastries"], "Gourmand Pastries Belgium"),
            ("bridor.fr", ["Bridor"], "Bridor viennoiserie"),
            ("bakery-news.com", ["Bakery News"], "Bakery industry news about bakery"),  # « Bakery SPA » est générique
            ("foodservice-bakery.eu", ["Foodservice Bakery"], ""),
        ]
        for domain, names, text in unknown:
            self.assertIsNone(self.directory.match(names, domain, text), domain)

    def test_official_name_from_file_stem(self):
        self.assertEqual(self.directory.canonical_for_stem("KOHBERG_catalogue_2025"), "Kohberg Bakery Group A S")
        self.assertEqual(self.directory.canonical_for_stem("Panificio_Stefani_2025"), "Panificio Stefani Group Srl")
        self.assertIsNone(self.directory.canonical_for_stem("PANIFICIO_catalogue"))  # plusieurs fournisseurs : ambigu
        self.assertIsNone(self.directory.canonical_for_stem("BRIDOR_catalogue"))


class SmallDirectoryTests(unittest.TestCase):
    def test_empty_directory_matches_nothing(self):
        self.assertIsNone(SupplierDirectory().match(["Kohberg"], "kohberg.com"))

    def test_comments_and_blank_lines_are_ignored(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "list.txt"
            path.write_text("# commentaire\n\nACME FOODS SRL\n", encoding="utf-8")
            self.assertEqual(len(SupplierDirectory.from_file(path)), 1)


if __name__ == "__main__":
    unittest.main()
