import tempfile
import unittest
from pathlib import Path

from pypdf import PdfReader

from sourcing.pdf_split import MAX_PART_BYTES, PageTooLargeError, PdfSplitError, split_pdf
from tests.pdf_factory import write_pdf


class SplitTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_small_pdf_is_kept_as_is(self):
        src = write_pdf(self.tmp / "petit.pdf", ["page 1", "page 2"])
        parts = split_pdf(src, self.tmp / "out", stem="petit")
        self.assertEqual(len(parts), 1)
        self.assertEqual(parts[0].path.name, "petit_part_01_pages_1-2.pdf")
        self.assertEqual((parts[0].start_page, parts[0].end_page), (1, 2))

    def test_47_mb_pdf_is_split_under_9_mib_without_losing_pages(self):
        pages = 94
        src = write_pdf(self.tmp / "gros.pdf", [f"Page {i + 1}\nMini danish 40 g" for i in range(pages)],
                        filler_bytes_per_page=500_000)
        self.assertGreater(src.stat().st_size, 46_000_000)
        parts = split_pdf(src, self.tmp / "out", stem="Catalogue")
        self.assertGreater(len(parts), 1)
        self.assertTrue(all(p.size_bytes <= MAX_PART_BYTES for p in parts))
        self.assertTrue(all(p.path.stat().st_size <= MAX_PART_BYTES for p in parts))
        # pages contiguës, sans trou ni doublon
        self.assertEqual(parts[0].start_page, 1)
        for before, after in zip(parts, parts[1:]):
            self.assertEqual(after.start_page, before.end_page + 1)
        self.assertEqual(parts[-1].end_page, pages)
        # le texte de la première page de chaque partie correspond bien à la page d'origine
        for part in parts:
            first_text = PdfReader(str(part.path)).pages[0].extract_text()
            self.assertIn(f"Page {part.start_page}\n", first_text + "\n")
        self.assertEqual(sum(len(PdfReader(str(p.path)).pages) for p in parts), pages)

    def test_names_follow_the_original_convention_with_page_range(self):
        src = write_pdf(self.tmp / "g.pdf", [f"p{i}" for i in range(20)], filler_bytes_per_page=1_000_000)
        parts = split_pdf(src, self.tmp / "out", stem="Cat", max_bytes=4 * 1024 * 1024)
        self.assertEqual(parts[1].path.name, f"Cat_part_02_pages_{parts[1].start_page}-{parts[1].end_page}.pdf")

    def test_overweight_single_page_is_rasterized_when_pymupdf_is_available(self):
        from unittest import mock

        src = write_pdf(self.tmp / "monstre.pdf", ["a"], filler_bytes_per_page=3_000_000)
        with mock.patch("sourcing.pdf_render.fitz_available", return_value=True), mock.patch(
            "sourcing.pdf_render.rasterize_page_pdf", return_value=b"%PDF-1.4 petite page"
        ):
            parts = split_pdf(src, self.tmp / "out", stem="m", max_bytes=1024 * 1024)
        self.assertEqual((parts[0].start_page, parts[0].end_page, parts[0].size_bytes), (1, 1, 20))

    def test_still_too_heavy_after_rasterization_is_reported(self):
        from unittest import mock

        src = write_pdf(self.tmp / "monstre.pdf", ["a"], filler_bytes_per_page=3_000_000)
        with mock.patch("sourcing.pdf_render.fitz_available", return_value=True), mock.patch(
            "sourcing.pdf_render.rasterize_page_pdf", return_value=None
        ):
            with self.assertRaises(PageTooLargeError):
                split_pdf(src, self.tmp / "out", stem="m", max_bytes=1024 * 1024)

    def test_single_page_larger_than_limit_is_reported(self):
        src = write_pdf(self.tmp / "monstre.pdf", ["a"], filler_bytes_per_page=3_000_000)
        with self.assertRaises(PageTooLargeError) as ctx:
            split_pdf(src, self.tmp / "out", stem="m", max_bytes=1024 * 1024)
        self.assertIn("page 1", str(ctx.exception))
        self.assertIn("PyMuPDF", str(ctx.exception))

    def test_corrupt_pdf_gives_clear_error(self):
        bad = self.tmp / "casse.pdf"
        bad.write_bytes(b"%PDF-1.4 ceci n'est pas un vrai pdf" * 100)
        with self.assertRaises(PdfSplitError):
            split_pdf(bad, self.tmp / "out", stem="c", max_bytes=100)


if __name__ == "__main__":
    unittest.main()
