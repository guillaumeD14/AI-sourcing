import contextlib
import importlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from cloudinary_pdf_tools import RemotePdf
from sourcing.cache import BoundedTTLCache
from sourcing.indexer import sync_index
from sourcing.internal_search import search_internal
from sourcing.models import Evidence, Level, SupplierCandidate
from sourcing.shortlist import CSV_FIELDS, row_from_candidate, row_from_internal, to_csv_bytes
from sourcing.store import IndexStore
from tests.fakes import FakeRemote, FakeSearcher, result
from tests.pdf_factory import write_pdf
from tests.streamlit_stub import StreamlitStub, installed
from tests.test_indexer_search import CATALOGS, FakeClient

ROOT = Path(__file__).resolve().parent.parent
SECRETS = {
    "CLOUDINARY_CLOUD_NAME": "democloud", "CLOUDINARY_API_KEY": "123456789012345",
    "CLOUDINARY_API_SECRET": "SuperSecretValue987", "TAVILY_API_KEY": "tvly-SECRETKEY123456",
}
NO_AUTO_SYNC = {"Synchroniser au démarrage": False}
SEARCH = {"product": "Mini Danish", "weight": "40 g", "Rechercher dans les catalogues": True}


def run_app(stub: StreamlitStub, db: Path, patches=()):
    env = {"SOURCING_DB_PATH": str(db), "SOURCING_MANUFACTURERS_CSV": str(db.with_name("none.csv")),
           "SOURCING_KNOWN_SUPPLIERS": str(ROOT / "data" / "known_suppliers.txt")}
    with contextlib.ExitStack() as stack:
        stack.enter_context(mock.patch.dict(os.environ, env, clear=False))
        for name in SECRETS:
            os.environ.pop(name, None)
        for patch in patches:
            stack.enter_context(patch)
        stack.enter_context(installed(stub))
        importlib.import_module("app").main()


class FakeCloudinary:
    """Remplace CloudinaryClient : liste les catalogues de test et « télécharge » de vrais PDF."""

    downloads: list[str] = []

    def __init__(self, config):
        self.config = config

    def list_pdfs(self, prefix=None):
        return [RemotePdf(pid, "1", 1000, "e", "raw", "https://res.cloudinary.com/democloud/raw/upload/v1/x.pdf") for pid in CATALOGS]

    def download_to_file(self, remote, dest):
        FakeCloudinary.downloads.append(remote.public_id)
        write_pdf(Path(dest), CATALOGS[remote.public_id])
        return 1


class AppSmokeTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.db = self.tmp / "index.sqlite"
        FakeCloudinary.downloads = []

    def tearDown(self):
        self._tmp.cleanup()

    def texts(self, stub, kind=None):
        return [t for k, t in stub.messages if kind is None or k == kind]

    def indexed_store(self):
        store = IndexStore(self.db)
        sync_index(store, FakeClient(), [FakeRemote(p) for p in CATALOGS])
        return store

    def test_starts_without_any_secret_and_explains_what_is_missing(self):
        stub = StreamlitStub()
        run_app(stub, self.db)
        joined = " ".join(self.texts(stub))
        self.assertIn("CLOUDINARY_CLOUD_NAME", joined)
        self.assertIn("TAVILY_API_KEY", joined)
        self.assertIn("Lancez une recherche", joined)
        self.assertIn("Aucun catalogue synchronisé", joined)

    def test_search_results_are_rendered_from_the_index(self):
        self.indexed_store()
        stub = StreamlitStub(inputs=dict(SEARCH))
        run_app(stub, self.db)
        captions = " ".join(self.texts(stub, "caption"))
        self.assertIn("résultat(s)", captions)
        self.assertIn("grammage 40 g", captions)
        self.assertEqual([e for e in self.texts(stub, "error") if "non configuré" not in e], [])

    def test_criteria_are_understood_as_constraints(self):
        self.indexed_store()
        stub = StreamlitStub(inputs={**SEARCH, "criteria": "surgelé, private label, Italie"})
        run_app(stub, self.db)
        besoin = [t for t in self.texts(stub, "caption") if t.startswith("Besoin compris")][0]
        self.assertIn("pays : Italie", besoin)
        self.assertIn("private label", besoin)

    def test_secrets_are_never_displayed_and_prefix_is_shown(self):
        stub = StreamlitStub(secrets=dict(SECRETS), inputs={**SEARCH, **NO_AUTO_SYNC})
        run_app(stub, self.db)
        everything = " ".join(t for _, t in stub.messages)
        for value in SECRETS.values():
            self.assertNotIn(value, everything)
        self.assertIn("✅ Cloudinary configuré · dossier « ai-sourcing/catalogues »", everything)
        self.assertIn("✅ Tavily configuré", everything)

    def test_catalogs_are_synchronised_automatically_at_startup(self):
        stub = StreamlitStub(secrets=dict(SECRETS), inputs={"Synchroniser": False})
        run_app(stub, self.db, patches=[mock.patch("cloudinary_pdf_tools.CloudinaryClient", FakeCloudinary)])
        self.assertEqual(len(FakeCloudinary.downloads), 3)
        self.assertEqual(IndexStore(self.db).stats().indexed, 3)
        self.assertTrue(any("3 PDF indexé(s)" in t for t in self.texts(stub, "success")))
        # 2e session : rien à retélécharger
        stub2 = StreamlitStub(secrets=dict(SECRETS))
        run_app(stub2, self.db, patches=[mock.patch("cloudinary_pdf_tools.CloudinaryClient", FakeCloudinary)])
        self.assertEqual(len(FakeCloudinary.downloads), 3)

    def test_web_search_skips_known_suppliers_and_shows_how_it_searched(self):
        self.indexed_store()
        searcher = FakeSearcher(
            discovery=[result("https://www.kohberg.com/danish", "Mini Danish | Kohberg", "danish manufacturer", 0.9),
                       result("https://www.newmaker.nl/danish", "Mini Danish | NewMaker", "danish manufacturer factory", 0.8)],
            by_domain={"newmaker.nl": [result("https://www.newmaker.nl/producten/mini-danish", "Mini Danish 40 g | NewMaker", "mini danish 40 g", 0.9)]},
        )
        inputs = {**SEARCH, **NO_AUTO_SYNC, "Rechercher de nouveaux industriels": True}
        stub = StreamlitStub(secrets=dict(SECRETS), inputs=inputs)
        run_app(stub, self.db, patches=[mock.patch("sourcing.web_search.TavilyClient", lambda key: searcher)])
        captions = " ".join(self.texts(stub, "caption"))
        self.assertIn("1 candidat(s)", captions)
        self.assertIn("déjà dans votre liste : Kohberg Bakery Group A S", captions)
        self.assertIn("manufacturer", captions)  # requêtes de découverte affichées
        self.assertEqual(self.texts(stub, "error"), [])
        self.assertFalse(any(inc == ["kohberg.com"] for _, inc in searcher.calls))

    def test_shortlist_tab_offers_an_excel_friendly_csv(self):
        store = self.indexed_store()
        hit = search_internal(store, "Mini Danish 40 g")[0]
        stub = StreamlitStub()
        stub.session_state["decisions"] = {hit.key: ("Pertinent", row_from_internal(hit, "2026-10-07"))}
        run_app(stub, self.db)
        self.assertEqual(len(stub.downloads), 1)
        data = stub.downloads[0][0][1]
        self.assertTrue(data.startswith(b"\xef\xbb\xbf"))
        self.assertIn("MINI DANISH POMME", data.decode("utf-8-sig"))

    def test_no_deprecated_container_width_argument_for_streamlit_165(self):
        source = (ROOT / "app.py").read_text(encoding="utf-8")
        self.assertNotIn("use_container_width", source)
        self.assertIn('width="stretch"', source)


class ExportTests(unittest.TestCase):
    def candidate(self):
        c = SupplierCandidate(domain="danishfactory.dk", company="Danish Factory", country="Danemark", checked_on="2026-10-07")
        c.industrial_level = Level.CONFIRMED
        c.industrial_evidence = [Evidence("industriel", "https://www.danishfactory.dk/sites", checked_on="2026-10-07")]
        c.to_confirm = ["MOQ", "capacité industrielle"]
        c.score, c.max_score = 72.0, 100.0
        return c

    def test_missing_proof_is_written_as_non_trouve_publiquement_never_invented(self):
        row = row_from_candidate(self.candidate())
        self.assertEqual(row["lien page produit"], "Non trouvé publiquement")
        self.assertEqual(row["lien contact"], "Non trouvé publiquement")
        self.assertEqual(row["preuve produit"], "Non trouvé publiquement")
        self.assertIn("danishfactory.dk/sites", row["preuve industrielle"])

    def test_csv_columns_separator_and_encoding(self):
        raw = to_csv_bytes([("À étudier", row_from_candidate(self.candidate()))])
        text = raw.decode("utf-8-sig")
        header, line = text.splitlines()[0], text.splitlines()[1]
        self.assertEqual(header.split(";"), list(CSV_FIELDS))
        self.assertTrue(line.startswith("À étudier;recherche Internet;Danish Factory"))
        self.assertIn("date de vérification", header)

    def test_cache_is_bounded_and_expires(self):
        now = [0.0]
        cache = BoundedTTLCache(max_entries=2, ttl_seconds=10, clock=lambda: now[0])
        cache.set("a", 1); cache.set("b", 2); cache.set("c", 3)
        self.assertIsNone(cache.get("a"))
        self.assertEqual(cache.get("c"), 3)
        now[0] = 11
        self.assertIsNone(cache.get("c"))
        self.assertEqual(len(cache), 1)


if __name__ == "__main__":
    unittest.main()
