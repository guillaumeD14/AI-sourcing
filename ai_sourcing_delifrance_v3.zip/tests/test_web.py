import tempfile
import unittest
from datetime import date
from pathlib import Path

from sourcing.domains import EXCLUDE_DOMAINS, is_homepage, is_noise_domain
from sourcing.errors import AuthError, QuotaError
from sourcing.manufacturers import load_verified_manufacturers, select_seeds
from sourcing.models import Level
from sourcing.textutils import build_query_plan
from sourcing.web_search import TavilyClient, WebSearchOptions, WebSourcing, build_discovery_queries
from tests.fakes import FakeResponse, FakeSearcher, FakeSession, no_sleep, result

TODAY = date(2026, 10, 7)
PLAN = build_query_plan("Mini Danish 40 g")

OFFICIAL_INDUSTRY = (
    "Our factories and production sites in Denmark produce 120,000 tonnes per year. IFS and BRC certified. "
    "We supply private label and foodservice customers across Europe."
)


def danish_factory_results():
    return [
        result("https://www.danishfactory.dk/products/mini-danish-40g", "Mini Danish 40 g | Danish Factory",
               "Mini danish pastry 40 g, frozen, for foodservice. Carton of 120.", 0.9),
        result("https://www.danishfactory.dk/about/production-sites", "Production sites | Danish Factory", OFFICIAL_INDUSTRY, 0.8),
        result("https://www.danishfactory.dk/contact", "Contact sales | Danish Factory", "Contact our B2B sales team.", 0.6),
        result("https://www.danishfactory.dk/downloads/mini-danish-datasheet.pdf", "Mini Danish datasheet", "Technical data sheet", 0.5),
    ]


def discovery_results():
    return [
        result("https://www.amazon.fr/dp/B0123", "Mini danish surgelé", "Acheter des mini danish", 0.9),
        result("https://www.marmiton.org/recettes/danish.aspx", "Recette de danish", "Recette maison de danish", 0.9),
        result("https://www.danishfactory.dk/", "Danish Factory", "Industrial manufacturer of danish pastry for foodservice and private label", 0.9),
        result("https://www.danishfactory.dk/products", "Products", "Danish pastry manufacturer", 0.7),
        result("https://www.pastryworks.fr/", "PastryWorks", "Fabricant de viennoiserie", 0.6),
        result("https://www.shopbakery.com/danish", "Shop Bakery", "Distributor wholesale danish e-shop add to cart", 0.6),
        result("https://www.chinabake.cn/danish", "China Bake", "Danish manufacturer factory", 0.6),
    ]


def engine(searcher, **kwargs):
    return WebSourcing(searcher, today=lambda: TODAY, **kwargs)


class NoiseTests(unittest.TestCase):
    def test_marketplaces_recipes_social_are_noise(self):
        for url in ("https://www.amazon.fr/x", "https://www.marmiton.org/r", "https://fr.wikipedia.org/wiki/x",
                    "https://www.linkedin.com/company/y", "https://www.kompass.com/c/z", "https://www.aliexpress.com/i"):
            self.assertTrue(is_noise_domain(url), url)
        self.assertFalse(is_noise_domain("https://www.danishfactory.dk/"))

    def test_exclude_list_fits_tavily_limit(self):
        self.assertLessEqual(len(EXCLUDE_DOMAINS), 150)

    def test_homepage_detection(self):
        for url in ("https://a.com/", "https://a.com", "https://a.com/fr", "https://a.com/en-gb/index.html"):
            self.assertTrue(is_homepage(url), url)
        self.assertFalse(is_homepage("https://a.com/products/danish"))


class TavilyClientTests(unittest.TestCase):
    def client(self, responses):
        session = FakeSession(responses)
        return TavilyClient("tvly-SECRETKEY123456", session_factory=lambda: session, sleep=no_sleep), session

    def test_bearer_header_payload_and_results(self):
        client, session = self.client([FakeResponse(200, {"results": [{"url": "https://a.com/x", "title": "t"}, {"title": "sans url"}]})])
        out = client.search("mini danish", include_domains=["a.com"], max_results=5)
        self.assertEqual(len(out), 1)
        kwargs = session.calls[0][2]
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer tvly-SECRETKEY123456")
        self.assertEqual(kwargs["json"]["include_domains"], ["a.com"])
        self.assertIsNotNone(kwargs["timeout"])

    def test_invalid_key_and_quota_messages(self):
        with self.assertRaises(AuthError) as auth:
            self.client([FakeResponse(401)])[0].search("x")
        self.assertNotIn("SECRETKEY", str(auth.exception))
        with self.assertRaises(QuotaError):
            self.client([FakeResponse(432)])[0].search("x")

    def test_missing_key_and_repr(self):
        with self.assertRaises(AuthError):
            TavilyClient("")
        self.assertNotIn("SECRETKEY", repr(self.client([FakeResponse(200, {})])[0]))


class PipelineTests(unittest.TestCase):
    def searcher(self):
        return FakeSearcher(
            discovery=discovery_results(),
            by_domain={
                "danishfactory.dk": danish_factory_results(),
                "pastryworks.fr": [result("https://www.pastryworks.fr/", "PastryWorks", "Fabricant de viennoiserie", 0.5)],
                "shopbakery.com": [result("https://www.shopbakery.com/danish", "Danish", "Distributor wholesale e-shop add to cart danish", 0.5)],
            },
        )

    def run_engine(self, **kwargs):
        return engine(self.searcher(), **kwargs).run(PLAN)

    def by_domain(self, report):
        return {c.domain: c for c in report.candidates}

    def test_noise_and_non_european_domains_are_excluded(self):
        report = self.run_engine()
        domains = set(self.by_domain(report))
        self.assertNotIn("amazon.fr", domains)
        self.assertNotIn("marmiton.org", domains)
        self.assertNotIn("chinabake.cn", domains)
        self.assertGreaterEqual(report.excluded_results, 3)

    def test_confirmed_manufacturer_has_official_deep_links_and_dates(self):
        factory = self.by_domain(self.run_engine())["danishfactory.dk"]
        self.assertEqual(factory.status, "fabricant confirmé")
        self.assertEqual(factory.product_page_url, "https://www.danishfactory.dk/products/mini-danish-40g")
        self.assertTrue(factory.datasheet_url.endswith(".pdf"))
        self.assertTrue(factory.contact_url.endswith("/contact"))
        self.assertEqual(factory.country, "Danemark")
        self.assertEqual(factory.weights_g, [40.0])
        self.assertEqual(factory.private_label, Level.CONFIRMED)
        self.assertEqual(factory.foodservice, Level.CONFIRMED)
        self.assertIn("IFS", factory.certifications)
        self.assertEqual(factory.checked_on, "2026-10-07")
        self.assertTrue(all(e.url.startswith("https://www.danishfactory.dk") for e in factory.industrial_evidence))

    def test_homepage_only_is_never_a_confirmed_manufacturer(self):
        works = self.by_domain(self.run_engine())["pastryworks.fr"]
        self.assertIsNone(works.product_page_url)
        self.assertNotEqual(works.status, "fabricant confirmé")
        self.assertNotEqual(works.industrial_level, Level.CONFIRMED)

    def test_distributor_is_not_confirmed(self):
        shop = self.by_domain(self.run_engine()).get("shopbakery.com")
        self.assertIsNotNone(shop)
        self.assertTrue(shop.distributor_signals)
        self.assertNotEqual(shop.status, "fabricant confirmé")
        self.assertIn("signaux de distributeur / revendeur", shop.penalties)

    def test_discovery_text_alone_cannot_confirm(self):
        """Une page « officielle » n'est celle trouvée par la requête ciblée sur le domaine, pas par la découverte."""
        searcher = FakeSearcher(discovery=discovery_results(), by_domain={})
        report = engine(searcher).run(PLAN)
        factory = self.by_domain(report)["danishfactory.dk"]
        self.assertNotEqual(factory.status, "fabricant confirmé")
        self.assertEqual(factory.industrial_evidence, [])

    def test_ranking_orders_confirmed_first_and_explains_score(self):
        report = self.run_engine()
        self.assertEqual(report.candidates[0].domain, "danishfactory.dk")
        top = report.candidates[0]
        self.assertAlmostEqual(sum(top.components.values()) - sum(top.penalties.values()), top.score, places=1)
        self.assertEqual(top.max_score, 100.0)

    def test_wrong_weight_scores_lower(self):
        heavy = [result("https://www.danishfactory.dk/products/mini-danish", "Mini Danish 85 g", "Mini danish pastry 85 g", 0.9)] + danish_factory_results()[1:]
        searcher = FakeSearcher(discovery=discovery_results()[2:4], by_domain={"danishfactory.dk": heavy})
        wrong = {c.domain: c for c in engine(searcher).run(PLAN).candidates}["danishfactory.dk"]
        right = self.by_domain(self.run_engine())["danishfactory.dk"]
        self.assertLess(wrong.components["grammage"], right.components["grammage"])

    def test_query_budget_is_respected(self):
        searcher = self.searcher()
        report = engine(searcher, options=WebSearchOptions(max_queries=5)).run(PLAN)
        self.assertLessEqual(report.queries_used, 5)
        self.assertLessEqual(len(searcher.calls), 5)

    def test_no_result_is_reported_honestly(self):
        report = engine(FakeSearcher()).run(PLAN)
        self.assertEqual(report.candidates, [])

    def test_invalid_key_stops_without_crash(self):
        searcher = FakeSearcher(error=AuthError("Tavily refuse la clé API (401)."))
        report = engine(searcher).run(PLAN)
        self.assertEqual(report.candidates, [])
        self.assertTrue(any("401" in w for w in report.warnings))
        self.assertLessEqual(len(searcher.calls), WebSearchOptions().discovery_queries)

    def test_known_suppliers_are_skipped_by_default_and_flagged_when_included(self):
        searcher = self.searcher()
        report = engine(searcher, known_suppliers=["Danish Factory"]).run(PLAN)
        self.assertNotIn("danishfactory.dk", self.by_domain(report))
        self.assertEqual([(d, k) for _, d, k in report.known_skipped], [("danishfactory.dk", "Danish Factory")])
        self.assertFalse(any(inc == ["danishfactory.dk"] for _, inc in searcher.calls))  # aucun quota dépensé pour lui
        included = engine(self.searcher(), known_suppliers=["Danish Factory"], options=WebSearchOptions(include_known=True)).run(PLAN)
        factory = self.by_domain(included)["danishfactory.dk"]
        self.assertTrue(factory.known_supplier)
        self.assertEqual(factory.known_as, "Danish Factory")
        self.assertFalse(self.by_domain(included)["pastryworks.fr"].known_supplier)

    def test_discovery_queries_cover_french_english_and_weight(self):
        queries = build_discovery_queries(PLAN)
        joined = " ".join(queries).lower()
        for expected in ("manufacturer", "fabricant", "foodservice", "private label", "40 g"):
            self.assertIn(expected, joined)
        self.assertLessEqual(len(queries), 4)

    def test_progress_callback_reaches_the_end(self):
        seen = []
        engine(self.searcher()).run(PLAN, progress=lambda label, fraction: seen.append(fraction))
        self.assertEqual(seen[-1], 1.0)
        self.assertTrue(all(0 <= f <= 1 for f in seen))


CSV_TEXT = """company,domain,country,categories,product_keywords,industrial_evidence_url,product_page_url,datasheet_url,contact_url,private_label,foodservice,source_note,verified_on
Verified Bakery SA,verifiedbakery.es,Espagne,viennoiserie;patisserie,danish;croissant,https://www.verifiedbakery.es/en/factories,https://www.verifiedbakery.es/en/products/danish,,https://www.verifiedbakery.es/contact,oui,oui,Pages officielles lues le 2026-10-01,2026-10-01
Pizza Only,pizzaonly.it,Italie,autre,pizza,https://www.pizzaonly.it/plants,,,,,,,Pages officielles,2026-10-01
Sans date,nodate.fr,France,viennoiserie,danish,https://nodate.fr/usine,,,,,,,
# commentaire
"""


class VerifiedBaseTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.path = Path(self._tmp.name) / "verified.csv"
        self.path.write_text(CSV_TEXT, encoding="utf-8")

    def tearDown(self):
        self._tmp.cleanup()

    def test_rows_without_date_or_domain_are_ignored(self):
        rows = load_verified_manufacturers(self.path)
        self.assertEqual([r.domain for r in rows], ["verifiedbakery.es", "pizzaonly.it"])

    def test_shipped_base_has_no_pre_loaded_supplier(self):
        shipped = Path(__file__).resolve().parent.parent / "data" / "verified_manufacturers.csv"
        self.assertEqual(load_verified_manufacturers(shipped), [])

    def test_missing_file_is_an_empty_base(self):
        self.assertEqual(load_verified_manufacturers(self.path.with_name("absent.csv")), [])

    def test_only_relevant_seeds_are_selected(self):
        seeds = select_seeds(load_verified_manufacturers(self.path), PLAN)
        self.assertEqual([s.domain for s in seeds], ["verifiedbakery.es"])

    def test_verified_manufacturer_surfaces_even_if_the_web_does_not_find_it(self):
        manufacturers = load_verified_manufacturers(self.path)
        report = engine(FakeSearcher(), manufacturers=manufacturers).run(PLAN)
        seed = {c.domain: c for c in report.candidates}["verifiedbakery.es"]
        self.assertTrue(seed.from_verified_base)
        self.assertEqual(seed.status, "fabricant confirmé")
        self.assertEqual(seed.country, "Espagne")
        self.assertEqual(seed.industrial_evidence[0].origin, "base vérifiée")
        self.assertEqual(seed.industrial_evidence[0].checked_on, "2026-10-01")
        self.assertEqual(seed.product_page_url, "https://www.verifiedbakery.es/en/products/danish")

    def test_base_never_confirms_a_product_it_does_not_cover(self):
        manufacturers = load_verified_manufacturers(self.path)
        plan = build_query_plan("Baguette tradition 250 g")
        seed = {c.domain: c for c in engine(FakeSearcher(), manufacturers=manufacturers).run(plan).candidates}.get("verifiedbakery.es")
        if seed:
            self.assertNotEqual(seed.product_level, Level.CONFIRMED)


if __name__ == "__main__":
    unittest.main()
