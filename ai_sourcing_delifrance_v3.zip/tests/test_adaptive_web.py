import re
import unittest
from datetime import date
from pathlib import Path

from sourcing.domains import company_from_titles
from sourcing.suppliers import SupplierDirectory
from sourcing.textutils import build_query_plan
from sourcing.web_search import WebSearchOptions, WebSourcing, build_discovery_queries, learn_terms
from tests.fakes import FakeSearcher, result

ROOT = Path(__file__).resolve().parent.parent
TODAY = date(2026, 10, 8)


def run(searcher, request, **kwargs):
    options = kwargs.pop("options", None)
    return WebSourcing(searcher, today=lambda: TODAY, options=options, **kwargs).run(build_query_plan(request))


class NoHardCodedSupplierTests(unittest.TestCase):
    NAMES = ("lantmannen", "lantmännen", "kohberg", "europastry", "la lorraine", "llbg", "gourmand", "bridor", "aryzta",
             "vandemoortele", "dawn foods", "pidy", "banquet d'or")

    def test_no_supplier_name_in_code(self):
        files = [ROOT / "app.py", ROOT / "cloudinary_pdf_tools.py", *(ROOT / "sourcing").glob("*.py")]
        for path in files:
            text = path.read_text(encoding="utf-8").lower()
            for name in self.NAMES:
                self.assertFalse(name in text, f"« {name} » codé en dur dans {path.name}")

    def test_no_supplier_url_in_code(self):
        for path in [ROOT / "app.py", *(ROOT / "sourcing").glob("*.py")]:
            urls = re.findall(r"https?://[^\s\"')]+", path.read_text(encoding="utf-8"))
            allowed = ("api.tavily.com", "api.cloudinary.com", "res.cloudinary.com")
            self.assertTrue(all(any(a in u for a in allowed) for u in urls), f"{path.name}: {urls}")


class QueryAdaptationTests(unittest.TestCase):
    def joined(self, request):
        return " | ".join(build_discovery_queries(build_query_plan(request)))

    def test_queries_follow_the_request_not_a_fixed_bakery_template(self):
        tiramisu = self.joined("tiramisu 90 g")
        self.assertIn("tiramisu 90 g", tiramisu)
        self.assertNotIn("bakery", tiramisu.lower())
        self.assertNotIn("danish", tiramisu.lower())
        self.assertIn("danish", self.joined("Mini Danish 40 g").lower())
        self.assertNotIn("tiramisu", self.joined("Mini Danish 40 g").lower())

    def test_attributes_are_translated_into_both_languages(self):
        text = self.joined("pizza surgelée bio 350 g")
        self.assertIn("frozen", text)
        self.assertIn("organic", text)
        self.assertIn("surgelée", text)

    def test_requested_countries_drive_region_and_local_language(self):
        text = self.joined("tiramisu 90 g private label Espagne")
        self.assertIn("Spain", text)
        self.assertIn("fabricante", text)
        self.assertNotIn("Hersteller", text)
        self.assertIn("Europe", self.joined("tiramisu 90 g"))

    def test_private_label_is_not_repeated_when_already_requested(self):
        for query in build_discovery_queries(build_query_plan("tiramisu 90 g private label Espagne"))[:2]:
            for term in ("private label", "marque distributeur"):
                self.assertLessEqual(query.lower().count(term), 1, query)

    def test_pain_suisse_is_a_pastry_not_a_country(self):
        plan = build_query_plan("pain suisse 60 g")
        self.assertEqual(plan.countries, ())
        self.assertEqual(build_query_plan("pain en Suisse").countries, ("Suisse",))

    def test_feedback_terms_come_from_results_and_contain_the_request(self):
        plan = build_query_plan("Mini Danish 40 g")
        results = [result("https://a.eu/x", "Danish pastries mix | Maker A", "Frozen danish pastries"),
                   result("https://b.eu/y", "Danish pastries for foodservice | Maker B", "danish pastries range"),
                   result("https://c.eu/z", "Cooking blog", "nothing relevant here")]
        terms = learn_terms(results, plan)
        self.assertIn("danish pastries", terms)
        self.assertTrue(all(set(t.split()) & set(plan.tokens) for t in terms))

    def test_feedback_queries_are_run_and_reported_within_budget(self):
        discovery = [result(f"https://maker{i}.eu/p", f"Danish pastries range | Maker{i}", "Danish pastries manufacturer") for i in range(3)]
        searcher = FakeSearcher(discovery=discovery)
        report = run(searcher, "Mini Danish 40 g")
        self.assertIn("danish pastries", report.learned_terms)
        self.assertTrue(any(q.startswith("danish pastries") for q in report.queries))
        self.assertLessEqual(report.queries_used, WebSearchOptions().max_queries)

    def test_company_name_comes_from_page_titles(self):
        self.assertEqual(company_from_titles("kohberg.com", ["Mini Danish Mix | Kohberg"]), "Kohberg")


class NonBakeryEndToEndTests(unittest.TestCase):
    def test_a_different_product_is_qualified_with_the_same_rules(self):
        searcher = FakeSearcher(
            discovery=[result("https://www.dolcimakers.it/", "Dolci Makers", "Produttore industriale di dessert", 0.9),
                       result("https://www.amazon.it/dp/1", "Tiramisù surgelato", "Compra", 0.9)],
            by_domain={"dolcimakers.it": [
                result("https://www.dolcimakers.it/prodotti/tiramisu-90g", "Tiramisu 90 g | Dolci Makers", "Tiramisu monoporzione 90 g surgelato", 0.9),
                result("https://www.dolcimakers.it/azienda/stabilimenti", "Stabilimenti | Dolci Makers",
                       "I nostri stabilimenti e siti di produzione: 40.000 tonnellate. Private label e foodservice.", 0.8)]},
        )
        report = run(searcher, "tiramisu 90 g Italie")
        maker = {c.domain: c for c in report.candidates}["dolcimakers.it"]
        self.assertEqual(maker.country, "Italie")
        self.assertEqual(maker.product_page_url, "https://www.dolcimakers.it/prodotti/tiramisu-90g")
        self.assertEqual(maker.weights_g, [90.0])
        self.assertEqual(maker.components["pays demandé"], 10.0)
        self.assertNotIn("amazon.it", {c.domain for c in report.candidates})


class KnownSupplierFlowTests(unittest.TestCase):
    def test_known_supplier_from_real_list_is_skipped_before_spending_quota(self):
        directory = SupplierDirectory.from_file(ROOT / "data" / "known_suppliers.txt")
        searcher = FakeSearcher(
            discovery=[result("https://www.kohberg.com/danish", "Mini Danish | Kohberg", "danish manufacturer", 0.9),
                       result("https://www.newmaker.nl/danish", "Mini Danish | NewMaker", "danish manufacturer factory", 0.8)],
            by_domain={"newmaker.nl": [result("https://www.newmaker.nl/producten/mini-danish", "Mini Danish 40 g | NewMaker", "mini danish 40 g", 0.9)]},
        )
        report = run(searcher, "Mini Danish 40 g", directory=directory)
        self.assertEqual([k for _, _, k in report.known_skipped], ["Kohberg Bakery Group A S"])
        self.assertEqual([c.domain for c in report.candidates], ["newmaker.nl"])
        self.assertFalse(any(inc == ["kohberg.com"] for _, inc in searcher.calls))


if __name__ == "__main__":
    unittest.main()
