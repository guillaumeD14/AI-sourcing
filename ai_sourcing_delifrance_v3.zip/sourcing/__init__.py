"""Briques métier de l'application AI Sourcing Délifrance (sans dépendance Streamlit)."""

__version__ = "2.0.0"
